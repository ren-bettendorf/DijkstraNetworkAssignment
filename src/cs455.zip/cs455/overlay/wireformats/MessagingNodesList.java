package cs455.overlay.wireformats;

public class MessagingNodesList {

}
